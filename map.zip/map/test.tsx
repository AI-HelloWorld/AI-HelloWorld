<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="test" tilewidth="32" tileheight="32" tilecount="352" columns="22">
 <image source="the_ville2.png" width="719" height="513"/>
</tileset>
