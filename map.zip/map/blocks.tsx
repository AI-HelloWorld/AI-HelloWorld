<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="blocks" tilewidth="32" tileheight="32" spacing="1" margin="1" tilecount="216" columns="9">
 <image source="pixel_map.png" width="329" height="824"/>
</tileset>
